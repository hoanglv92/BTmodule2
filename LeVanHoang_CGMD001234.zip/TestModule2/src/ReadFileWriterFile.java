import java.io.*;
import java.util.ArrayList;

public class ReadFileWriterFile {

}
